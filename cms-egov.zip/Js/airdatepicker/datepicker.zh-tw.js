;(function ($) { $.fn.datepicker.language['zh-tw'] = {
    days: ['週日', '週一', '週二', '週三', '週四', '週五', '週六'],
    daysShort: ['日', '一', '二', '三', '四', '五', '六'],
    daysMin: ['日', '一', '二', '三', '四', '五', '六'],
    months: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    monthsShort: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    today: '今日',
    clear: '清除',
    dateFormat: 'rrr/mm/dd',
    timeFormat: 'hh:ii aa',
    firstDay: 0
}; })(jQuery);